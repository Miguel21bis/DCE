--ARM Defence Script
--by Marc "MBot" Marbot
--Version 21.12.2014
--This script gives radars a chance to detect anti-radar missiles launched against them and to shut down for self-preservation
------------------------------------------------------------------------------------------------------- 
-- last modification:  cleanCode_a
if not versionDCE then versionDCE = {} end
versionDCE["Mission Scripts/ARM_Defence_Script.lua"] = "1.3.7"
------------------------------------------------------------------------------------------------------- 
 
-- cleanCode_a			 
-- Reglage_b			(b more difficult with Patriot&Sa10)(a: RadarOn 6 a 9mn)			
-- Debug_b 				(b getCategory)(a:AGM-154 :31:  'getDesc' Static doesn't exist)
------------------------------------------------------------------------------------------------------- 	

	
do
	local function RadarOn(ctrl)																				--Function to turn radar back on after a riding out the attack
		if ctrl ~= nil then
			ctrl:setOption(AI.Option.Ground.id.ALARM_STATE, AI.Option.Ground.val.ALARM_STATE.AUTO)				--Turn radar on
			--trigger.action.outText("Radar On", 3)	--DEBUG
		end
	end

	local function RadarOff(arg)																				--Function to shut down radar of attacked unit/group
		local grp = arg[1]:getGroup()																			--Get group of attached unit (radar can only be turned off for whole group)
		if grp ~= nil then
			local ctrl = grp:getController()																	--Get controller of group
			ctrl:setOption(AI.Option.Ground.id.ALARM_STATE, AI.Option.Ground.val.ALARM_STATE.GREEN)				--Turn off radar
			--trigger.action.outText("Radar Off", 3)	--DEBUG
			-- timer.scheduleFunction(RadarOn, ctrl, timer.getTime() + math.random(120, 240))						--Schedule turning radar back on in 2 to 4 minutes
			timer.scheduleFunction(RadarOn, ctrl, timer.getTime() + math.random(360, 540))						--Schedule turning radar back on in 6 to 9 minutes
		end
	end

	ARM_Shot_EventHandler = {}																					--Event handler to look for launched ARM
	function ARM_Shot_EventHandler:onEvent(event)
		if event.id == world.event.S_EVENT_SHOT then
			local wep = event.weapon																			--Get the weapon of the launch event
			local tgt = wep:getTarget()																			--Get the target of the weapon
			
			-- if event.initiator and Object.getCategory(event.initiator) == Object.Category.UNIT  then										--initiator is a unit debug_ET01.h
			-- 	env.info("DCE_ARM_S_EVENT A SHOT getPlayerName "..tostring( event.initiator:getPlayerName()))
			-- end
			
			-- env.info("DCE_ARM_S_EVENT    B SHOT tgt "..tostring(tgt))
			if tgt and tgt:isExist() then
				
				local desc = wep:getDesc()
				env.info("DCE_ARM_S_EVENT       C ")
				-- _affiche(desc, "DCE desc weapon ArmDS")

				-- Weapon.MissileCategory = {
				-- 	AAM,
				-- 	SAM,
				-- 	BM,
				-- 	ANTI_SHIP,
				-- 	CRUISE,
				-- 	OTHER
				--   }

				-- Weapon.GuidanceType = {
				-- 	INS,
				-- 	IR,
				-- 	RADAR_ACTIVE,
				-- 	RADAR_SEMI_ACTIVE,
				-- 	RADAR_PASSIVE,
				-- 	TV,
				-- 	LASER,
				-- 	TELE
				--   }

				if desc.missileCategory == 6 and desc.guidance == 5 then										--Check if the weapon is an ARM
					-- env.info("DCE_ARM_S_EVENT          D ")

					-- Object.Category
					-- UNIT    1
					-- WEAPON  2
					-- STATIC  3
					-- BASE    4
					-- SCENERY 5
					-- Cargo   6

					local objCat = Object.getCategory(tgt)

					if objCat ~= Object.Category.SCENERY then														--target is not a scenery object
						env.info("DCE_ARM_S_EVENT          E Object_Category: "..tostring(Object_Category[objCat]))

						local unitCat = tgt:getDesc().category
						env.info("DCE_ARM_S_EVENT          E unitCat: "..tostring(unitCat))
						if unitCat ~= 3 then															--target is not a ship	-- bug AGM-154 :31: in function 'getDesc' Static doesn't exist
							-- trigger.action.outText("ARM Launch", 3)	--DEBUG
							-- env.info("DCE_ARM_               F Launch")
							
							local descRadarSam = tgt:getDesc()

							-- _affiche(descRadarSam, "descRadarSam ArmDefence")

							SAM_AMM = {
								["Patriot str"] = true,
								["S-300PS 40B6M tr"] = true,
							}

							if math.random(1,10) > 1 then																--90% chance that ARM launch is detected by target
								local probaTurnOff = 75

								if descRadarSam and descRadarSam.typeName and SAM_AMM[descRadarSam.typeName] then
									probaTurnOff = 25
								end
								
								if math.random(1,100) <= probaTurnOff then
									-- trigger.action.outText("RadarOff", 3)	--DEBUG
									env.info("DCE_ARM_RadarOff")
									timer.scheduleFunction(RadarOff, {tgt, wep}, timer.getTime() + math.random(5, 15))		--Target reacts within 5 to 15 seconds after ARM launch with shutting down its radar
								end
							
							end
						end
					end
					
					-- if tgt:getDesc().category ~= 3 then															--target is not a ship	-- bug AGM-154 :31: in function 'getDesc' Static doesn't exist
					-- local desc = wep:getDesc()
						-- if desc.missileCategory == 6 and desc.guidance == 5 then										--Check if the weapon is an ARM
							-- --trigger.action.outText("ARM Launch", 3)	--DEBUG
							-- if math.random(1,10) > 1 then																--90% chance that ARM launch is detected by target
								-- timer.scheduleFunction(RadarOff, {tgt, wep}, timer.getTime() + math.random(5, 15))		--Target reacts within 5 to 15 seconds after ARM launch with shutting down its radar
							-- end
						-- end
					-- end
					
					
				end
			end
		end
	end
	world.addEventHandler(ARM_Shot_EventHandler)
end